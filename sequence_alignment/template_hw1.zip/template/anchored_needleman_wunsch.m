function [score, alignment1, aligner, alignment2] = anchored_needleman_wunsch(seq1, seq2, match, mismatch, gap, matched_regions)
% anchored_needleman_wunsch Perform the anchored version of the 
% Needleman-Wunsch algorithm.
%
% Input variables:
% seq1: string containing the first sequence
% seq2: string containing the second sequence
% match: numeric value which represents the score for match
% mismatch: numeric value which represents the penalty for mismatch
% gap: numeric value which represents the penalty for gap
% matched_regions: contains regions which are know to be aligned. The
% regions may contain matches and/or mismatches. The first column contains
% the starting position of the first sequence; the second column contains
% the ending position of the first sequence; the third column contains the
% starting position of the second sequence; and the forth column contains
% the ending position of the second sequence. E.g.: a row containing [17,
% 20, 76, 79] means that seq1(17:20) should be aligned to seq2(76:79),
% containing only matches and/or mismatches in this region.
%
% Output variables:
% score: numeric value containing the alignment score
% alignment1: string containing the alignment (including gaps) of the first
% sequence
% aligner: string containing symbols (pipe |) which aligns the 2 sequences
% alignment2: string containing the alignment (including gaps) of the
% second sequence
%
% Output example:
% AV--TNAGQLV---S  <--- alignment1
% ||  || |||    |  <--- aligner
% AQVSTN-GQL-AQVT  <--- alignment2
%
%
%%%%%%%%%%%%%% YOUR CODE STARTS HERE



end


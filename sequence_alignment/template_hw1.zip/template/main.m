%% load sequences
seq1 = fastaread('Human_HOX.fa');
seq1 = seq1.Sequence;
seq2 = fastaread('Fly_HOX.fa');
seq2 = seq2.Sequence;

%% penalties
gap = -2;
match = 1;
mismatch = -3;

%% anchored needleman wunsch
matched_regions = dlmread('Match_HOX.txt');
[score, alignment1, aligner, alignment2] = anchored_needleman_wunsch(seq1, seq2, match, mismatch, gap, matched_regions);

%% perform alignment of random sequences 10,000 times
acc_scores = [];
for i=1:1e4
    % generate random sequence 1 and 2 using seq1 and seq2
    % seq1_rand = ...
    % seq2_rand = ...
    
    % call anchored_needleman_wunsch and store scores into acc_scores
    % ...
    % ...
end

%% plot random scores and actual score (uncomment below to plot)
% figure1 = figure;
% axes1 = axes('Parent',figure1);
% histogram(acc_scores)
% hold on
% histogram(score)
% grid on; grid minor;
% legend({'Random Sequences', 'Alignment Score'});
% xlabel('Score'); ylabel('Frequency');
% set(axes1,'FontSize',14);
